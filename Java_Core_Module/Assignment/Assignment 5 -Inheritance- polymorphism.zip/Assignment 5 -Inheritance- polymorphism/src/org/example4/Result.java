package org.example4;

public class Result extends Student {
    
    private final int Subjects;     
    private final int totalMarks;   
    private int marksObtained;    

    public Result(String name, int rollno, int age, int Subjects, int totalMarks, int marksObtained) {
        super(name, rollno, age);  
        this.Subjects = Subjects;  
        this.totalMarks = totalMarks;
        this.marksObtained = marksObtained;
    }

    public int getSubjects() {
        return Subjects;
    }

    public int getTotalMarks() {
        return totalMarks;
    }

    public int getMarksObtained() {
        return marksObtained;
    }

    public void setMarksObtained(int marksObtained) {
        this.marksObtained = marksObtained;
    }

    @Override
    public String toString() {
        return "Name: " + getName() + 
               ", Roll No: " + getRollno() + 
               ", Age: " + getAge() + 
               ", Subjects: " + Subjects + 
               ", Total Marks: " + totalMarks + 
               ", Marks Obtained: " + marksObtained;
    }
    
    public String student() {
    	return "Name: " + getName() + 
                ", Roll No: " + getRollno() + 
                ", Age: " + getAge();
    }
    
    public String Studresult() {
    	return ", Subjects: " + Subjects + 
                ", Total Marks: " + totalMarks + 
                ", Marks Obtained: " + marksObtained;
    }
    
}
