package org.example4;

import java.util.Scanner;

public class Resultdetail {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
        System.out.println("Enter Student Name:");
        String name = sc.nextLine();
        
        System.out.println("Enter Roll Number:");
        int rollno = sc.nextInt();
        
        System.out.println("Enter Age:");
        int age = sc.nextInt();
        
        System.out.println("Enter Number of Subjects:");
        int subjects = sc.nextInt();
        
        System.out.println("Enter Total Marks:");
        int totalMarks = sc.nextInt();
        
        System.out.println("Enter Marks Obtained:");
        int marksObtained = sc.nextInt();
        
        Result result = new Result(name, rollno, age, subjects, totalMarks, marksObtained);
        
        System.out.println("\nStudent Details:");
        System.out.println(result.student());

        System.out.println("\nResult Details:");
        System.out.println(result.toString());
        	
		
		sc.close();
	}
}
