package org.example1;

public class vehicle {
	 private String make;  
	 private int year;     
	
	 public vehicle(String make, int year) {
	     this.make = make;
	     this.year = year;
	 }
	
	 public String getMake() {
	     return make;
	 }
	
	 public int getYear() {
	     return year;
	 }
}

