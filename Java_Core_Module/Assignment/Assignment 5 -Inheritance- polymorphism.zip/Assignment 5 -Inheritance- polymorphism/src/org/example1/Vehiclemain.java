package org.example1;

public class Vehiclemain {
	public static void main(String[] args) {
        Car myCar = new Car("Toyota", 2021, "Corolla");

        System.out.println("Car Make: " + myCar.getMake());
        System.out.println("Car Year: " + myCar.getYear());
        System.out.println("Car Model: " + myCar.getModel());
    }
}

