package org.example1;

public class Car extends vehicle {
 private String model;  

 public Car(String make, int year, String model) {
     super(make, year);  
     this.model = model;
 }

 public String getModel() {
     return model;
 }
}

