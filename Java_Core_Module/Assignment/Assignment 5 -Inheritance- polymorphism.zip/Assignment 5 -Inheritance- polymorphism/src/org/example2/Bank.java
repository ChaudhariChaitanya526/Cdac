package org.example2;

import java.util.Scanner;

class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: " + amount);
        } else {
            System.out.println("Invalid or insufficient funds for withdrawal.");
        }
    }

    public double getBalance() {
        return balance;
    }
}

class SavingsAccount extends BankAccount {
    private static final double WITHDRAWAL_LIMIT = 500.00;

    public SavingsAccount(double initialBalance) {
        super(initialBalance);
    }

    @Override
    public void withdraw(double amount) {
        if (amount > 0 && amount <= WITHDRAWAL_LIMIT) {
            super.withdraw(amount);
        } else {
            System.out.println("Withdrawal amount exceeds the limit of " + WITHDRAWAL_LIMIT);
        }
    }
}

public class Bank {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        BankAccount account = new BankAccount(1000.00);
        SavingsAccount savings = new SavingsAccount(1000.00);

        boolean exit = false;
        while (!exit) {
            System.out.println("\n=== Bank Menu ===");
            System.out.println("1. Deposit into BankAccount");
            System.out.println("2. Withdraw from BankAccount");
            System.out.println("3. Deposit into SavingsAccount");
            System.out.println("4. Withdraw from SavingsAccount");
            System.out.println("5. Check BankAccount Balance");
            System.out.println("6. Check SavingsAccount Balance");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter deposit amount for BankAccount: ");
                    double depositAmount = sc.nextDouble();
                    account.deposit(depositAmount);
                    break;

                case 2:
                    System.out.print("Enter withdrawal amount for BankAccount: ");
                    double withdrawAmount = sc.nextDouble();
                    account.withdraw(withdrawAmount);
                    break;

                case 3:
                    System.out.print("Enter deposit amount for SavingsAccount: ");
                    depositAmount = sc.nextDouble();
                    savings.deposit(depositAmount);
                    break;

                case 4:
                    System.out.print("Enter withdrawal amount for SavingsAccount: ");
                    withdrawAmount = sc.nextDouble();
                    savings.withdraw(withdrawAmount);
                    break;

                case 5:
                    System.out.println("BankAccount Balance: " + account.getBalance());
                    break;

                case 6:
                    System.out.println("SavingsAccount Balance: " + savings.getBalance());
                    break;

                case 7:
                    exit = true;
                    System.out.println("Exiting the application...");
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }

        sc.close(); 
    }
}
