package org.example;

import java.util.Scanner;

//public class Bank {	
//    public static void main(String[] args) {
//        BankAccount account = new BankAccount(1000.00);
//        account.deposit(200.00);
//        account.withdraw(150.00);
//        System.out.println("BankAccount Balance: " + account.getBalance());
//
//        SavingsAccount savings = new SavingsAccount(1000.00);
//        savings.deposit(200.00);
//        savings.withdraw(600.00);  
//        savings.withdraw(300.00);  
//        System.out.println("SavingsAccount Balance: " + savings.getBalance());
//    }
//}



public class Bank {
	
	private static Scanner sc = new Scanner(System.in);	
	
    public static void main(String[] args) {

        BankAccount account = new BankAccount(1000.00);
        
        System.out.print("Enter deposit amount for BankAccount: ");
        double depositAmount = sc.nextDouble();
        account.deposit(depositAmount);
        
        System.out.print("Enter withdrawal amount for BankAccount: ");
        double withdrawAmount = sc.nextDouble();
        account.withdraw(withdrawAmount);
        
        System.out.println("BankAccount Balance: " + account.getBalance());

        SavingsAccount savings = new SavingsAccount(1000.00);
        
        System.out.print("Enter deposit amount for SavingsAccount: ");
        depositAmount = sc.nextDouble();
        savings.deposit(depositAmount);
        
        System.out.print("Enter withdrawal amount for SavingsAccount: ");
        withdrawAmount = sc.nextDouble();
        savings.withdraw(withdrawAmount);
        
        System.out.print("Enter another withdrawal amount for SavingsAccount: ");
        withdrawAmount = sc.nextDouble();
        savings.withdraw(withdrawAmount);
        
        System.out.println("SavingsAccount Balance: " + savings.getBalance());

        sc.close();
    }
}
