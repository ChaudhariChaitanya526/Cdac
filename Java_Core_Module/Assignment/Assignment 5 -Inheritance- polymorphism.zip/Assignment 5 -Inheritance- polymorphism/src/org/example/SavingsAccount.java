package org.example;

public class SavingsAccount extends BankAccount {
    private static final double WITHDRAWAL_LIMIT = 500.00; 

    public SavingsAccount(double initialBalance) {
        super(initialBalance);
    }

    @Override
    public void withdraw(double amount) {
        if (amount > 0 && amount <= WITHDRAWAL_LIMIT) {
            super.withdraw(amount);  
        } else {
            System.out.println("Withdrawal amount exceeds the limit of " + WITHDRAWAL_LIMIT);
        }
    }
}