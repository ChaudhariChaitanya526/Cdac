package org.example5;

public class Motorcycle {

}
