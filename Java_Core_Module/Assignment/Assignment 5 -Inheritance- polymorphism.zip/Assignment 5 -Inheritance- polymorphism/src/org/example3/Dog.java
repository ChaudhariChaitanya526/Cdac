package org.example3;

class Dog extends Animal {
	
	public Dog(String name) {
		super(name);
	}
	
	public void bark() {
		System.out.println(name+ " is barking");
	}
}
