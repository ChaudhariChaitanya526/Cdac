package org.example3;

public class Animals {
	
	public static void main(String[] args) {
		
		Animal animal = new Animal("Generic Animal");
		
		animal.eat();
		animal.sleep();
		
		Dog dog = new Dog("Buddy");
		dog.eat();
		dog.sleep();
		dog.bark();
	}
}
