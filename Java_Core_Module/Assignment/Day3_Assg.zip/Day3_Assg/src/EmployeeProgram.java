import java.util.Scanner;

class Employee {
    private String name;
    private int empid;
    private float salary;

    public void acceptRecord() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Name: ");
        name = sc.nextLine();
        System.out.println("Empid: ");
        empid = sc.nextInt();
        System.out.println("salary: ");
        salary = sc.nextFloat();
    }

    public void printRecord() {
        System.out.println("Name: "+name);
        System.out.println("Empid: "+empid);
        System.out.println("Salary: "+salary);
    }
}
public class EmployeeProgram {
    public static void main(String[] args) {

        Employee emp1 = new Employee();

        emp1.acceptRecord();

        emp1.printRecord();

    }
}
