package org.example;

import java.util.Scanner;

class BMITracker {

    private double weight;        
    private double height;        
    private double bmi;           
    private String classification; 

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getBMI() {
        return bmi;
    }

    public String getClassification() {
        return classification;
    }

    public void acceptRecord() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter weight (in kilograms): ");
        this.setWeight(sc.nextDouble());

        System.out.print("Enter height (in meters): ");
        this.setHeight(sc.nextDouble());

        sc.close();
    }

    public void calculateBMI() {
        this.bmi = this.getWeight() / (this.getHeight() * this.getHeight());
    }

    public void classifyBMI() {
        if (this.getBMI() < 18.5) {
            this.classification = "Underweight";
        } else if (this.getBMI() >= 18.5 && this.getBMI() < 24.9) {
            this.classification = "Normal weight";
        } else if (this.getBMI() >= 25 && this.getBMI() < 29.9) {
            this.classification = "Overweight";
        } else {
            this.classification = "Obese";
        }
    }

    public void printRecord() {
        System.out.printf("Your BMI is: %.2f%n", this.getBMI());
        System.out.println("BMI Classification: " + this.getClassification());
    }
}

public class BMI_Cal {

    public static void main(String[] args) {

        BMITracker bmiTracker = new BMITracker();

        bmiTracker.acceptRecord();

        bmiTracker.calculateBMI();
        bmiTracker.classifyBMI();

        bmiTracker.printRecord();
    }
}
