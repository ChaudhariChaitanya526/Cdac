/**
 * 
 */
/**
 * @author Chaitanya
 *
 */
module Que2 {
}