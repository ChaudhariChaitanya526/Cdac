package org.example;

import java.util.Scanner;

class TollBoothRevenueManager {

    private double carTollRate;        
    private double truckTollRate;      
    private double motorcycleTollRate; 

    private int numCars;               
    private int numTrucks;             
    private int numMotorcycles;        

    private double totalRevenue;       
    private int totalVehicles;         

    public double getCarTollRate() {
        return carTollRate;
    }

    public void setCarTollRate(double carTollRate) {
        this.carTollRate = carTollRate;
    }

    public double getTruckTollRate() {
        return truckTollRate;
    }

    public void setTruckTollRate(double truckTollRate) {
        this.truckTollRate = truckTollRate;
    }

    public double getMotorcycleTollRate() {
        return motorcycleTollRate;
    }

    public void setMotorcycleTollRate(double motorcycleTollRate) {
        this.motorcycleTollRate = motorcycleTollRate;
    }

    public int getNumCars() {
        return numCars;
    }

    public void setNumCars(int numCars) {
        this.numCars = numCars;
    }

    public int getNumTrucks() {
        return numTrucks;
    }

    public void setNumTrucks(int numTrucks) {
        this.numTrucks = numTrucks;
    }

    public int getNumMotorcycles() {
        return numMotorcycles;
    }

    public void setNumMotorcycles(int numMotorcycles) {
        this.numMotorcycles = numMotorcycles;
    }

    public double getTotalRevenue() {
        return totalRevenue;
    }

    public int getTotalVehicles() {
        return totalVehicles;
    }

    public void setTollRates() {
        Scanner sc = new Scanner(System.in);  

        System.out.print("Enter toll rate for Car (₹): ");
        this.setCarTollRate(sc.nextDouble());

        System.out.print("Enter toll rate for Truck (₹): ");
        this.setTruckTollRate(sc.nextDouble());

        System.out.print("Enter toll rate for Motorcycle (₹): ");
        this.setMotorcycleTollRate(sc.nextDouble());

    }

    public void acceptRecord() {
        Scanner sc = new Scanner(System.in);  

        System.out.print("Enter number of Cars passing through the toll: ");
        this.setNumCars(sc.nextInt());

        System.out.print("Enter number of Trucks passing through the toll: ");
        this.setNumTrucks(sc.nextInt());

        System.out.print("Enter number of Motorcycles passing through the toll: ");
        this.setNumMotorcycles(sc.nextInt());

    }

    public void calculateRevenue() {
        this.totalRevenue = (this.getNumCars() * this.getCarTollRate()) +
                            (this.getNumTrucks() * this.getTruckTollRate()) +
                            (this.getNumMotorcycles() * this.getMotorcycleTollRate());

        this.totalVehicles = this.getNumCars() + this.getNumTrucks() + this.getNumMotorcycles();
    }

    public void printRecord() {
        System.out.println("Total number of vehicles passed through the toll booth: " + this.getTotalVehicles());
        System.out.printf("Total revenue collected: ₹%.2f%n", this.getTotalRevenue());
    }
}

public class Toll_Booth_Rev {
	
	public static void main(String[] args) {

        TollBoothRevenueManager tollBooth = new TollBoothRevenueManager();

        tollBooth.setTollRates();

        tollBooth.acceptRecord();

        tollBooth.calculateRevenue();

        tollBooth.printRecord();
		
	}
}
