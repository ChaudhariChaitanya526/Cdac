package org.example;

import java.util.Scanner;

class DiscountCalculator {

    private double originalPrice;   
    private double discountRate;     
    private double discountAmount;   
    private double finalPrice;      

    public double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(double originalPrice) {
        this.originalPrice = originalPrice;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    public double getDiscountAmount() {
        return discountAmount;
    }

    public double getFinalPrice() {
        return finalPrice;
    }

    public void acceptRecord() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the original price of the item (in ₹): ");
        this.setOriginalPrice(sc.nextDouble());

        System.out.print("Enter the discount rate (in %): ");
        this.setDiscountRate(sc.nextDouble());

        sc.close();
    }

    public void calculateDiscount() {
        this.discountAmount = this.getOriginalPrice() * (this.getDiscountRate() / 100);
        this.finalPrice = this.getOriginalPrice() - this.getDiscountAmount();
    }

    public void printRecord() {
        System.out.printf("Discount Amount: ₹%.2f%n", this.getDiscountAmount());
        System.out.printf("Final Price after discount: ₹%.2f%n", this.getFinalPrice());
    }
}

public class Discount_Cal {
	
    public static void main(String[] args) {

        DiscountCalculator discountCalc = new DiscountCalculator();

        discountCalc.acceptRecord();

        discountCalc.calculateDiscount();

        discountCalc.printRecord();
    }
}
