/*Loan Amortization Calculator
Implement a system to calculate and display the monthly payments for a mortgage loan. The system should:
1.	Accept the principal amount (loan amount), annual interest rate, and loan term (in years) from the user.
2.	Calculate the monthly payment using the standard mortgage formula:
o	Monthly Payment Calculation:
	monthlyPayment = principal * (monthlyInterestRate * (1 + monthlyInterestRate)^(numberOfMonths)) / ((1 + monthlyInterestRate)^(numberOfMonths) - 1)
	Where monthlyInterestRate = annualInterestRate / 12 / 100 and numberOfMonths = loanTerm * 12
	Note: Here ^ means power and to find it you can use Math.pow( ) method
3.	Display the monthly payment and the total amount paid over the life of the loan, in Indian Rupees (₹).
Define class LoanAmortizationCalculator with methods acceptRecord, calculateMonthlyPayment & printRecord and test the functionality in main method.
*/

package org.example;
import java.util.Scanner;

class LoanAmortizationCalculator {
	
	private double principal_amount;
	private double annual_interest_rate;
	private int loan_term;
	private double monthly_payment;
	
	
	public double getPrincipal_amount() {
		return principal_amount;
	}

	public void setPrincipal_amount(double principal_amount) {
		this.principal_amount = principal_amount;
	}

	public double getAnnual_interest_rate() {
		return annual_interest_rate;
	}

	public void setAnnual_interest_rate(double annual_interest_rate) {
		this.annual_interest_rate = annual_interest_rate;
	}

	public int getLoan_term() {
		return loan_term;
	}

	public void setLoan_term(int loan_term) {
		this.loan_term = loan_term;
	}
	

	public void acceptRecord() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter amount of Loan: ");
		this.setPrincipal_amount(sc.nextDouble());
		
		System.out.print("Enter annual interest rate: ");
		this.setAnnual_interest_rate( sc.nextDouble() );
		
		System.out.print("Enter loan term (in years): ");
		this.setLoan_term( sc.nextInt() );
		
		sc.close();
	}
	
	public void calculateMonthlyPayment() {
		double monthlyInterestRate = (this.getAnnual_interest_rate() / 12) / 100;
		int numberOfMonths = this.loan_term * 12;
		
		this.monthly_payment = this.getPrincipal_amount() * (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfMonths)) /
                (Math.pow(1 + monthlyInterestRate, numberOfMonths) - 1);
	}
	
	public void printRecord() {
		double totalPayment = this.monthly_payment * this.getLoan_term() * 12;
		
		System.out.printf("Monthly Payment: ₹%.2f%n", this.monthly_payment);
		System.out.printf("Total amount paid over the life of the loan (in Indian Rupees ₹): ₹%.2f%n", totalPayment);
	}
}

public class Loan_Cal {
	
	public static void main(String[] args) {
		LoanAmortizationCalculator loan_cal = new LoanAmortizationCalculator();
		
		loan_cal.acceptRecord();
	
		loan_cal.calculateMonthlyPayment();
		
		loan_cal.printRecord();
	}
}
