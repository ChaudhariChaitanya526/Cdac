/**
 * 
 */
/**
 * @author Chaitanya
 *
 */
module Que1 {
}