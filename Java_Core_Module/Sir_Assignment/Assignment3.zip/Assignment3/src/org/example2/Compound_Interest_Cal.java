package org.example2;

import java.util.Scanner; 

class CompoundInterestCalculator {
	
	private double initial_investment_amount;  
	private double annual_interest_rate;       
	private int compounded_interest_year;     
	private int investment_duration;           
	private double future_value;               
	private double total_interest;             
	
	// Method to accept input from the user
	public void acceptRecord() {
		Scanner sc = new Scanner(System.in);  
		
		System.out.print("Enter initial investment amount: ");
		this.initial_investment_amount = sc.nextDouble();
		
		System.out.print("Enter annual interest rate (in %): ");
		this.annual_interest_rate = sc.nextDouble();

		System.out.print("Enter number of times the interest is compounded per year: ");
		this.compounded_interest_year = sc.nextInt();

		System.out.print("Enter investment duration (in years): ");
		this.investment_duration = sc.nextInt();
		
		sc.close();
	}
	
	
	public void calculateFutureValue() {
		double ratePerPeriod = this.annual_interest_rate / this.compounded_interest_year / 100;
		int totalPeriods = this.compounded_interest_year * this.investment_duration;

		this.future_value = this.initial_investment_amount * Math.pow(1 + ratePerPeriod, totalPeriods);
		
		this.total_interest = this.future_value - this.initial_investment_amount;
	}
	
	public void printRecord() {
		System.out.printf("Future Value of the Investment: ₹%.2f%n", this.future_value);
		System.out.printf("Total Interest Earned: ₹%.2f%n", this.total_interest);
	}
	
}

public class Compound_Interest_Cal {

	public static void main(String[] args) {
		CompoundInterestCalculator comp_int = new CompoundInterestCalculator();

		comp_int.acceptRecord();
		comp_int.calculateFutureValue();
		comp_int.printRecord();
		
	}
}
