package org.example5;

import java.util.Scanner;

class TollBoothRevenueManager {

    private double carTollRate;
    private double truckTollRate;
    private double motorcycleTollRate;

    private int numCars;
    private int numTrucks;
    private int numMotorcycles;

    private double totalRevenue;
    private int totalVehicles;

    public void setTollRates() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter toll rate for Car (₹): ");
        this.carTollRate = sc.nextDouble();

        System.out.print("Enter toll rate for Truck (₹): ");
        this.truckTollRate = sc.nextDouble();

        System.out.print("Enter toll rate for Motorcycle (₹): ");
        this.motorcycleTollRate = sc.nextDouble();
        
        sc.close();
    }

    public void acceptRecord() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of Cars passing through the toll: ");
        this.numCars = sc.nextInt();

        System.out.print("Enter number of Trucks passing through the toll: ");
        this.numTrucks = sc.nextInt();

        System.out.print("Enter number of Motorcycles passing through the toll: ");
        this.numMotorcycles = sc.nextInt();
    }

    public void calculateRevenue() {
        this.totalRevenue = (this.numCars * this.carTollRate) +
                            (this.numTrucks * this.truckTollRate) +
                            (this.numMotorcycles * this.motorcycleTollRate);

        this.totalVehicles = this.numCars + this.numTrucks + this.numMotorcycles;
    }

    public void printRecord() {
        System.out.println("Total number of vehicles passed through the toll booth: " + this.totalVehicles);
        System.out.printf("Total revenue collected: ₹%.2f%n", this.totalRevenue);
    }
}


public class Toll_Booth_Rev {
	
	public static void main(String[] args) {

        TollBoothRevenueManager tollBooth = new TollBoothRevenueManager();

        tollBooth.setTollRates();

        tollBooth.acceptRecord();

        tollBooth.calculateRevenue();

        tollBooth.printRecord();
		
	}

}
