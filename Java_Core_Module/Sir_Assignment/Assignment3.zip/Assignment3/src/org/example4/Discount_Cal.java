package org.example4;


import java.util.Scanner;

class DiscountCalculator {

    private double originalPrice;
    private double discountRate;
    private double discountAmount;
    private double finalPrice;

    
    public void acceptRecord() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the original price of the item (in ₹): ");
        this.originalPrice = sc.nextDouble();

        System.out.print("Enter the discount rate (in %): ");
        this.discountRate = sc.nextDouble();
        
        sc.close();
    }

    
    public void calculateDiscount() {
        this.discountAmount = this.originalPrice * (this.discountRate / 100);
        this.finalPrice = this.originalPrice - this.discountAmount;
    }

    
    public void printRecord() {
        System.out.printf("Discount Amount: ₹%.2f%n", this.discountAmount);
        System.out.printf("Final Price after discount: ₹%.2f%n", this.finalPrice);
    }
}

public class Discount_Cal {
	
	public static void main(String[] args) {
        DiscountCalculator discountCalc = new DiscountCalculator();

        discountCalc.acceptRecord();
        discountCalc.calculateDiscount();
        discountCalc.printRecord();
	}

}
