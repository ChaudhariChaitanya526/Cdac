package org.example3;

import java.util.Scanner;

class BMITracker {
	
	private double weight;
	private double height;
	private double bmi;
	private String classification;
	
	public void acceptRecord() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter weight (in kilograms) : ");
		this.weight = sc.nextDouble();
		
		System.out.print("Enter height (in meters): ");
		this.height = sc.nextDouble();
		
		sc.close();
		
	}
	
	public void calculateBMI() {
		
		this.bmi = this.weight / (this.height * this.height);
		
	}
	
	public void classifyBMI() {
		if (this.bmi < 18.5) {
            this.classification = "Underweight";
        } else if (this.bmi >= 18.5 && this.bmi < 24.9) {
            this.classification = "Normal weight";
        } else if (this.bmi >= 25 && this.bmi < 29.9) {
            this.classification = "Overweight";
        } else {
            this.classification = "Obese";
        }
	}
	
	public void printRecord() {
		System.out.printf("Your BMI is: %.2f%n", this.bmi);
        System.out.println("BMI Classification: " + this.classification);
	}
	
}

public class BMI_Cal {
	
	
	public static void main(String[] args) {
		
		BMITracker BMI = new BMITracker();
		
		BMI.acceptRecord();
		
		BMI.calculateBMI();
		
		BMI.classifyBMI();
		
		BMI.printRecord();
		
	}
	

}
