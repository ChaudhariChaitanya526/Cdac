package org.example;

import java.util.Scanner;

class Employee {
    private static int totalEmployees = 0;
    private static double totalSalaryExpense = 0;

    private int id;
    private String name;
    private double salary;

    static {
        totalEmployees = 0;
        totalSalaryExpense = 0;
    }

    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        totalEmployees++;
        totalSalaryExpense += salary;
    }

    public static int getTotalEmployees() {
        return totalEmployees;
    }

    public void applyRaise(double percentage) {
        double raiseAmount = (salary * percentage) / 100;
        salary += raiseAmount;
        totalSalaryExpense += raiseAmount;
    }

    public void updateSalary(double newSalary) {
        totalSalaryExpense = totalSalaryExpense - this.salary + newSalary;
        this.salary = newSalary;
    }

    public static double calculateTotalSalaryExpense() {
        return totalSalaryExpense;
    }

    @Override
    public String toString() {
        return "Employee ID: " + id + ", Name: " + name + ", Salary: " + salary;
    }
}

public class EmployeeData {
	
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Employee[] employees = new Employee[100]; 
        int empCount = 0;

        boolean exit = false;
        while (!exit) {
            System.out.println("\nMenu:");
            System.out.println("1. Add Employee");
            System.out.println("2. Apply Raise");
            System.out.println("3. Update Salary");
            System.out.println("4. Show Total Employees");
            System.out.println("5. Show Total Salary Expense");
            System.out.println("6. Show Employee Details");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Salary: ");
                    double salary = sc.nextDouble();
                    employees[empCount++] = new Employee(id, name, salary);
                    break;

                case 2:
                    System.out.print("Enter percentage raise: ");
                    double percentage = sc.nextDouble();
                    for (int i = 0; i < empCount; i++) {
                        employees[i].applyRaise(percentage);
                    }
                    System.out.println("Raise applied to all employees.");
                    break;

                case 3:
                    System.out.print("Enter Employee ID: ");
                    int updateId = sc.nextInt();
                    System.out.print("Enter new salary: ");
                    double newSalary = sc.nextDouble();
                    for (int i = 0; i < empCount; i++) {
                        if (employees[i].toString().contains("Employee ID: " + updateId)) {
                            employees[i].updateSalary(newSalary);
                            System.out.println("Salary updated.");
                            break;
                        }
                    }
                    break;

                case 4:
                    System.out.println("Total Employees: " + Employee.getTotalEmployees());
                    break;

                case 5:
                    System.out.println("Total Salary Expense: " + Employee.calculateTotalSalaryExpense());
                    break;

                case 6:
                    for (int i = 0; i < empCount; i++) {
                        System.out.println(employees[i]);
                    }
                    break;

                case 7:
                    exit = true;
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
        sc.close();
    }
}
