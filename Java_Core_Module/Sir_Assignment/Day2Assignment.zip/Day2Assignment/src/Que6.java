public class Que6 {

    public static void SubQue1() {
        //Write a program to test how many bytes are used to represent a float value using the BYTES field. (Hint: Use Float.BYTES).
        System.out.println("Bytes used to represent a float: " + Float.BYTES);
    }

    public static void SubQue2() {
        //Write a program to find the minimum and maximum values of float using the MIN_VALUE and MAX_VALUE fields. (Hint: Use Float.MIN_VALUE and Float.MAX_VALUE).
        System.out.println("Minimum value of float: " + Float.MIN_VALUE);
        System.out.println("Maximum value of float: " + Float.MAX_VALUE);
    }


    public static void SubQue3() {
        //Declare a method-local variable number of type float with some value and convert it to a String using the toString method. (Hint: Use Float.toString(float)).
        float number = 123.45f;

        String numberAsString = Float.toString(number);

        System.out.println("The float as a String is: " + numberAsString);
    }


    public static void SubQue4() {
        //Declare a method-local variable strNumber of type String with some value and convert it to a float value using the parseFloat method. (Hint: Use Float.parseFloat(String)).
        String strNumber = "456.78";

        float number = Float.parseFloat(strNumber);

        System.out.println("The String as a float is: " + number);
    }


    public static void SubQue5() {
        //Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to a float value. (Hint: parseFloat method will throw a NumberFormatException).
        String strNumber = "Ab12Cd3";

        try {
            float number = Float.parseFloat(strNumber);
            System.out.println("The String as a float is: " + number);
        } catch (NumberFormatException e) {
            System.out.println("Error: The string '" + strNumber + "' cannot be converted to a float.");
            System.out.println("Exception: " + e.getMessage());
    }
    }


    public static void SubQue6() {
        //Declare a method-local variable number of type float with some value and convert it to the corresponding wrapper class using Float.valueOf(). (Hint: Use Float.valueOf(float)).
        float num = 78.9f;

        Float numberWrapper = Float.valueOf(num);

        System.out.println("The float as a Float wrapper class is: " + numberWrapper);
    }


    public static void SubQue7() {
        //Declare a method-local variable strNumber of type String with some float value and convert it to the corresponding wrapper class using Float.valueOf(). (Hint: Use Float.valueOf(String)).
        String strNumber = "123.45";

        Float numberWrapper = Float.valueOf(strNumber);

        System.out.println("The String as a Float wrapper class is: " + numberWrapper);
    }


    public static void SubQue8() {
        //Declare two float variables with values 112.3 and 984.5, and add them using a method from the Float class. (Hint: Use Float.sum(float, float)).
        float num1 = 112.3f;
        float num2 = 984.5f;

        float sum = Float.sum(num1, num2);

        System.out.println("The sum of " + num1 + " and " + num2 + " is: " + sum);
    }

    public  static  void SubQue9() {
        //. Declare two float variables with values 112.2 and 556.6, and find the minimum and maximum values using the Float class. (Hint: Use Float.min(float, float) and Float.max(float, float)).
        float num1 = 112.2f;
        float num2 = 556.6f;

        float min = Float.min(num1, num2);
        float max = Float.max(num1, num2);

        System.out.println("Minimum value is: " + min);
        System.out.println("Maximum value is: " + max);
    }

    public  static  void SubQue10() {
        //. Declare a float variable with the value -25.0f. Find the square root of this value. (Hint: Use Math.sqrt() method).
        float number = -25.0f;

        double sqrtValue = Math.sqrt(number);

        System.out.println("The square root of " + number + " is: " + sqrtValue);
    }


    public  static  void SubQue11() {
        //Declare two float variables with the same value, 0.0f, and divide them. (Hint: Observe the result and any special floating-point behavior).
        float num1 = 0.0f;
        float num2 = 0.0f;

        float result = num1 / num2;

        System.out.println("Result of 0.0f / 0.0f is: " + result);
    }


    public  static  void SubQue12() {
        //Experiment with converting a float value into other primitive types or vice versa and observe the results.
        float floatValue = 123.45f;

        int intValue = (int) floatValue;
        double doubleValue = (double) floatValue;
        long longValue = (long) floatValue;
        byte byteValue = (byte) floatValue;

        System.out.println("Float value: " + floatValue);
        System.out.println("Converted to int: " + intValue);
        System.out.println("Converted to double: " + doubleValue);
        System.out.println("Converted to long: " + longValue);
        System.out.println("Converted to byte: " + byteValue);
    }



    public static void main(String[] args) {

        SubQue1();
        SubQue2();
        SubQue3();
        SubQue4();
        SubQue5();
        SubQue6();
        SubQue7();
        SubQue8();
        SubQue9();
        SubQue10();
        SubQue11();
        SubQue12();

    }
}
