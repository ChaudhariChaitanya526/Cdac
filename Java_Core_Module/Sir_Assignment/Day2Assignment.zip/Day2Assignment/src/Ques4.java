public class Ques4 {

    public static void SubQue1() {
        // Write a program to test how many bytes are used to represent an int value using the BYTES field. (Hint: Use Integer.BYTES).
        int bytesUsed = Integer.BYTES;

        System.out.println("Number of bytes used by an int " + bytesUsed + " bytes.");

    }

    public static void SubQue2() {
        // Write a program to find the minimum and maximum values of int using the MIN_VALUE and MAX_VALUE fields. (Hint: Use Integer.MIN_VALUE and Integer.MAX_VALUE).
        int Min_int = Integer.MIN_VALUE;
        int Max_int = Integer.MAX_VALUE;

        System.out.println("Minimum int " + Min_int);
        System.out.println("Maximum int " + Max_int);

    }

    public static void SubQue3() {
        // . Declare a method-local variable number of type int with some value and convert it to a String using the toString method. (Hint: Use Integer.toString(int)).
        int number = 123;

        String numberAsString = Integer.toString(number);

        System.out.println("The number as a String is: " + numberAsString);
    }

    public static void SubQue4() {
        // Declare a method-local variable strNumber of type String with some value and convert it to an int value using the parseInt method. (Hint: Use Integer.parseInt(String)).
        String strNumber = "123";

        int num = Integer.parseInt(strNumber);

        System.out.println("The string as an int is: " + num);
    }

    public static void SubQue5() {
        // Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to an int value. (Hint: parseInt method will throw a NumberFormatException).
        String strNumber = "Ab12Cd3";

        try {
            int num = Integer.parseInt(strNumber);
            System.out.println("The string as an int is: " + num);
        } catch (NumberFormatException e) {
            System.out.println("Error: The string '" + strNumber + "' cannot be converted to an int.");
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public static void SubQue6() {
        // Declare a method-local variable number of type int with some value and convert it to the corresponding wrapper class using Integer.valueOf(). (Hint: Use Integer.valueOf(int)).
        int number = 42;

        Integer wrapperNumber = Integer.valueOf(number);

        System.out.println("The int as an Integer object is: " + wrapperNumber);
    }

    public static void SubQue7() {
        // Declare a method-local variable strNumber of type String with some integer value and convert it to the corresponding wrapper class using Integer.valueOf(). (Hint: Use Integer.valueOf(String)).
        String strNumber = "123";

        Integer wrapperNumber = Integer.valueOf(strNumber);

        System.out.println("The String as an Integer object is: " + wrapperNumber);
    }

    public static void SubQue8() {
        // Declare two integer variables with values 10 and 20, and add them using a method from the Integer class. (Hint: Use Integer.sum(int, int)).
        int num1 = 10;
        int num2 = 20;

        int sum = Integer.sum(num1, num2);

        System.out.println("Adding two integer value " + sum);
    }

    public static void SubQue9()  {
        // Declare two integer variables with values 10 and 20, and find the minimum and maximum values using the Integer class. (Hint: Use Integer.min(int, int) and Integer.max(int, int)).
        int num1 = 10;
        int num2 = 20;

        int Min_int = Integer.min(num1, num2);
        int Max_int = Integer.max(num1, num2);

        System.out.println("Maximum integer value " +Min_int);
        System.out.println("Maximum integer value " +Max_int);
    }

    public static void SubQue10() {
        // Declare an integer variable with the value 7. Convert it to binary, octal, and hexadecimal strings using methods from the Integer class. (Hint: Use Integer.toBinaryString(int), Integer.toOctalString(int), and Integer.toHexString(int)).
        int num = 10;

        String binaryString = Integer.toBinaryString(num);

        String octalString = Integer.toOctalString(num);

        String hexString = Integer.toHexString(num);

        System.out.println("The number" + num + "in binary is: " + binaryString);
        System.out.println("The number" + num + "in octal is: " + octalString);
        System.out.println("The number" + num + "in hexadecimal is: " + hexString);
    }

    public static void SubQue11() {
        // . Experiment with converting an int value into other primitive types or vice versa and observe the results..
        int intValue = 123;

        // Convert int to other primitive types
        byte byteValue = (byte) intValue; // Narrowing conversion
        short shortValue = (short) intValue; // Narrowing conversion
        long longValue = (long) intValue; // Widening conversion
        float floatValue = (float) intValue; // Widening conversion
        double doubleValue = (double) intValue; // Widening conversion

        // Convert other primitive types to int
        byte byteToInt = 10;
        short shortToInt = 100;
        long longToInt = 123456789L; // Explicit casting needed
        float floatToInt = 45.67f; // Explicit casting needed
        double doubleToInt = 89.99; // Explicit casting needed

        int intFromByte = (int) byteToInt; // Widening conversion
        int intFromShort = (int) shortToInt; // Widening conversion
        int intFromLong = (int) longToInt; // Narrowing conversion
        int intFromFloat = (int) floatToInt; // Narrowing conversion
        int intFromDouble = (int) doubleToInt; // Narrowing conversion

        System.out.println("Original int value: " + intValue);
        System.out.println("int to byte: " + byteValue);
        System.out.println("int to short: " + shortValue);
        System.out.println("int to long: " + longValue);
        System.out.println("int to float: " + floatValue);
        System.out.println("int to double: " + doubleValue);

        System.out.println("byte to int: " + intFromByte);
        System.out.println("short to int: " + intFromShort);
        System.out.println("long to int: " + intFromLong);
        System.out.println("float to int: " + intFromFloat);
        System.out.println("double to int: " + intFromDouble);

    }


    public static void main(String[] args) {

        SubQue1();
        SubQue2();
        SubQue3();
        SubQue4();
        SubQue5();
        SubQue6();
        SubQue7();
        SubQue8();
        SubQue9();
        SubQue10();
        SubQue11();

    }
}
