public class Que9 {
    // Instance variables (non-static fields)
    int intValue;
    long longValue;
    float floatValue;
    double doubleValue;
    boolean booleanValue;
    char charValue;
    byte byteValue;
    short shortValue;

    // Static variables (static fields)
    static int staticIntValue;
    static long staticLongValue;
    static float staticFloatValue;
    static double staticDoubleValue;
    static boolean staticBooleanValue;
    static char staticCharValue;
    static byte staticByteValue;
    static short staticShortValue;

    public static void main(String[] args) {
        // Create an instance of the class
        Que9 obj = new Que9();

        System.out.println("Instance variables:");
        System.out.println("int: " + obj.intValue);        // Default value: 0
        System.out.println("long: " + obj.longValue);      // Default value: 0L
        System.out.println("float: " + obj.floatValue);    // Default value: 0.0f
        System.out.println("double: " + obj.doubleValue);  // Default value: 0.0
        System.out.println("boolean: " + obj.booleanValue); // Default value: false
        System.out.println("char: " + obj.charValue);      // Default value: '\u0000' (null character)
        System.out.println("byte: " + obj.byteValue);      // Default value: 0
        System.out.println("short: " + obj.shortValue);    // Default value: 0


        System.out.println("Static variables:");
        System.out.println("int: " + staticIntValue);        // Default value: 0
        System.out.println("long: " + staticLongValue);      // Default value: 0L
        System.out.println("float: " + staticFloatValue);    // Default value: 0.0f
        System.out.println("double: " + staticDoubleValue);  // Default value: 0.0
        System.out.println("boolean: " + staticBooleanValue); // Default value: false
        System.out.println("char: " + staticCharValue);      // Default value: '\u0000' (null character)
        System.out.println("byte: " + staticByteValue);      // Default value: 0
        System.out.println("short: " + staticShortValue);    // Default value: 0
}
}
