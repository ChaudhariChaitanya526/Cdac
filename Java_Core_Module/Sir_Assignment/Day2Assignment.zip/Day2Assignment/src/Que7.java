public class Que7 {

    public static void SubQue1() {
        //Write a program to test how many bytes are used to represent a double value using the BYTES field. (Hint: Use Double.BYTES).
        System.out.println("Bytes used to represent a double: " + Double.BYTES);
    }

    public static void SubQue2() {
        //Write a program to find the minimum and maximum values of double using the MIN_VALUE and MAX_VALUE fields. (Hint: Use Double.MIN_VALUE and Double.MAX_VALUE).
        System.out.println("Minimum double value: " + Double.MIN_VALUE);
        System.out.println("Maximum double value: " + Double.MAX_VALUE);
    }

    public static void SubQue3() {
        //Declare a method-local variable number of type double with some value and convert it to a String using the toString method. (Hint: Use Double.toString(double)).
        double number = 123.456;

        String numberAsString = Double.toString(number);

        System.out.println("The double as a String is: " + numberAsString);
    }

    public static void SubQue4() {
        // Declare a method-local variable strNumber of type String with some value and convert it to a double value using the parseDouble method. (Hint: Use Double.parseDouble(String)).
        String strNumber = "123.456";

        double number = Double.parseDouble(strNumber);

        System.out.println("The string as a double is: " + number);
    }


    public static void SubQue5() {
        // Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to a double value. (Hint: parseDouble method will throw a NumberFormatException).
        String strNumber = "Ab12Cd3";

        try {
            double number = Double.parseDouble(strNumber);
            System.out.println("The string as a double is: " + number);
        } catch (NumberFormatException e) {
            System.out.println("Error: The string '" + strNumber + "' cannot be converted to a double.");
            System.out.println("Exception: " + e.getMessage());
        }
    }


    public static void SubQue6() {
        // Declare a method-local variable number of type double with some value and convert it to the corresponding wrapper class using Double.valueOf(). (Hint: Use Double.valueOf(double)).
        double number = 789.123;

        Double wrappedNumber = Double.valueOf(number);

        System.out.println("The wrapped double is: " + wrappedNumber);
    }


    public static void SubQue7() {
        // . Declare a method-local variable strNumber of type String with some double value and convert it to the corresponding wrapper class using Double.valueOf(). (Hint: Use Double.valueOf(String)).
        String strNumber = "456.789";

        Double wrappedNumber = Double.valueOf(strNumber);

        System.out.println("The wrapped double from String is: " + wrappedNumber);
    }


    public static void SubQue8() {
        // Declare two double variables with values 112.3 and 984.5, and add them using a method from the Double class. (Hint: Use Double.sum(double, double)).
        double num1 = 112.3;
        double num2 = 984.5;

        double sum = Double.sum(num1, num2);

        System.out.println("The sum of " + num1 + " and " + num2 + " is: " + sum);
    }

    public static void SubQue9() {
        // Declare two double variables with values 112.2 and 556.6, and find the minimum and maximum values using the Double class. (Hint: Use Double.min(double, double) and Double.max(double, double)).
        double num1 = 112.2;
        double num2 = 556.6;

        double min = Double.min(num1, num2);
        double max = Double.max(num1, num2);

        System.out.println("Minimum value is: " + min);
        System.out.println("Maximum value is: " + max);
    }


    public static void SubQue10() {
        // Declare a double variable with the value -25.0. Find the square root of this value. (Hint: Use Math.sqrt() method).
        double number = -25.0;

        double sqrtValue = Math.sqrt(number);  // This will return NaN for negative values

        System.out.println("The square root of " + number + " is: " + sqrtValue);
    }


    public static void SubQue11() {
        // Declare two double variables with the same value, 0.0, and divide them. (Hint: Observe the result and any special floating-point behavior).
        double num1 = 0.0;
        double num2 = 0.0;

        double result = num1 / num2;

        System.out.println("Result of 0.0 / 0.0 is: " + result);
    }


    public static void SubQue12() {
        // Experiment with converting a double value into other primitive types or vice versa and observe the results.
        double doubleValue = 123.456;

        int intValue = (int) doubleValue;
        long longValue = (long) doubleValue;
        float floatValue = (float) doubleValue;
        byte byteValue = (byte) doubleValue;

        System.out.println("Double value: " + doubleValue);
        System.out.println("Converted to int: " + intValue);
        System.out.println("Converted to long: " + longValue);
        System.out.println("Converted to float: " + floatValue);
        System.out.println("Converted to byte: " + byteValue);

    }


    public static void main(String[] args) {

        SubQue1();
        SubQue2();
        SubQue3();
        SubQue4();
        SubQue5();
        SubQue5();
        SubQue6();
        SubQue7();
        SubQue8();
        SubQue9();
        SubQue10();
        SubQue11();
        SubQue12();

    }
}
