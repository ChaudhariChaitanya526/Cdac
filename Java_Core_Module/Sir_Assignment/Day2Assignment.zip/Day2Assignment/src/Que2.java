public class Que2 {

    public static void SubQue1() {
        // Write a program to test how many bytes are used to represent a byte value using the BYTES field. (Hint: Use Byte.BYTES).
        int a = 10;
        System.out.println("Number of bytes used to represent a byte value: " + Byte.BYTES);
    }
    public static void SubQue2() {
        //  Write a program to find the minimum and maximum values of byte using the MIN_VALUE and MAX_VALUE fields. (Hint: Use Byte.MIN_VALUE and Byte.MAX_VALUE).
        System.out.println("Minimum value of a byte: " + Byte.MIN_VALUE);
        System.out.println("Maximum value of a byte: " + Byte.MAX_VALUE);

        // Minimum and Maximum values for int
        System.out.println("Minimum value of an int: " + Integer.MIN_VALUE);
        System.out.println("Maximum value of an int: " + Integer.MAX_VALUE);

        // Minimum and Maximum values for double
        System.out.println("Minimum value of a double: " + Double.MIN_VALUE);
        System.out.println("Maximum value of a double: " + Double.MAX_VALUE);

    }

    public static void SubQue3() {
        // Declare a method-local variable number of type byte with some value and convert it to a String using the toString method. (Hint: Use Byte.toString(byte)).
        byte num = 10;

        String str = Byte.toString(num);

        System.out.println("The byte value as string is " +str);
    }

    public static void SubQue4() {
        // Declare a method-local variable strNumber of type String with some value and convert it to a byte value using the parseByte method. (Hint: Use Byte.parseByte(String)).
        String strNumber = "127"; // You can choose any valid byte value here

        try {
            byte byteValue = Byte.parseByte(strNumber);

            System.out.println("The string as a byte is: " + byteValue);
        } catch (NumberFormatException e) {
            System.out.println("Error: The string '" + strNumber + "' cannot be converted to a byte.");
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public static void SubQue5() {
        // Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to a byte value. (Hint: parseByte method will throw a NumberFormatException).
        String strNumber = "Ab12Cd3";

        try {
            byte byteValue = Byte.parseByte(strNumber);
            System.out.println("Converted byte value: " + byteValue);
        } catch (NumberFormatException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void SubQue6() {
        // Declare a method-local variable number of type byte with some value and convert it to the corresponding wrapper class using Byte.valueOf(). (Hint: Use Byte.valueOf(byte)).
        byte num = 15;

        Byte byteWrapper = Byte.valueOf(num);

        System.out.println("The byte value as a Byte wrapper object is: " + byteWrapper);
    }

    public static void SubQue7() {
        // Declare a method-local variable strNumber of type String with some byte value and convert it to the corresponding wrapper class using Byte.valueOf(). (Hint: Use Byte.valueOf(String)).
        String strNumber = "25";

        Byte byteWrapper = Byte.valueOf(strNumber);

        System.out.println("The String value as a Byte wrapper object is: " +byteWrapper);
    }

    public static void SubQue8() {
        // Experiment with converting a byte value into other primitive types or vice versa and observe the results.
        byte byteValue = 100;

        // Convert byte to other primitive types
        int intValue = byteValue;
        long longValue = byteValue;
        float floatValue = byteValue;
        double doubleValue = byteValue;
        char charValue = (char) byteValue;
        boolean booleanValue = (byteValue != 0);

        // Print conversions from byte to other types
        System.out.println("byte to int: " + intValue);
        System.out.println("byte to long: " + longValue);
        System.out.println("byte to float: " + floatValue);
        System.out.println("byte to double: " + doubleValue);
        System.out.println("byte to char: " + charValue);
        System.out.println("byte to boolean: " + booleanValue);

        int intNum = 150;
        byte byteFromInt = (byte) intNum;

        double doubleNum = 99.99;
        byte byteFromDouble = (byte) doubleNum;

        // Print conversions from other types to byte
        System.out.println("int to byte: " + byteFromInt);
        System.out.println("double to byte: " + byteFromDouble);
    }


    public static void main(String[] args) {
        SubQue1();
        SubQue2();
        SubQue3();
        SubQue4();
        SubQue5();
        SubQue6();
        SubQue7();
        SubQue8();

    }
}
