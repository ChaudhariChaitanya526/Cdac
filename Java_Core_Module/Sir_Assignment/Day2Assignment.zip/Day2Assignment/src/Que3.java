public class Que3 {

    public static void SubQue1() {
        // Write a program to test how many bytes are used to represent a short value using the BYTES field. (Hint: Use Short.BYTES).
        System.out.println("Bytes used to represent a short: " + Short.BYTES);
    }
    public static void SubQue2() {
        // Write a program to find the minimum and maximum values of short using the MIN_VALUE and MAX_VALUE fields. (Hint: Use Short.MIN_VALUE and Short.MAX_VALUE)
        System.out.println("Minimum value of an int: " + Short.MIN_VALUE);
        System.out.println("Maximum value of an int: " + Short.MAX_VALUE);

    }
    public static void SubQue3() {
        // Declare a method-local variable number of type short with some value and convert it to a String using the toString method. (Hint: Use Short.toString(short)).
        short num = 123;
        // Boxing
        String shorttoString = Short.toString(num);

        System.out.println("short to String: " +shorttoString);
    }
    public static void SubQue4() {
        // Declare a method-local variable strNumber of type String with some value and convert it to a short value using the parseShort method. (Hint: Use Short.parseShort(String)).
        String strNumber = "12";
        //Unboxing
        short stringtoshort = Short.parseShort(strNumber);

        System.out.println("String to short: " +stringtoshort);
    }

    public static void SubQue5() {
        // Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to a short value. (Hint: parseShort method will throw a NumberFormatException).
        String strNumber = "Ab12Cd3";
        //Unboxing
        short stringtoshort = Short.parseShort(strNumber);

        try {
            // Attempt to convert the String to a short using Short.parseShort(String)
            short number = Short.parseShort(strNumber);
            System.out.println("Converted short value: " + number);
        } catch (NumberFormatException e) {
            // Handle the exception when the string cannot be parsed to a short
            System.out.println("NumberFormatException: Invalid input string \"" + strNumber + "\"");
        }

    }

    public static void SubQue6() {
        // Declare a method-local variable number of type short with some value and convert it to the corresponding wrapper class using Short.valueOf(). (Hint: Use Short.valueOf(short)).
        short num = 123;

        Short wrapperNumber = Short.valueOf(num);

        System.out.println("Wrapper class value: " + wrapperNumber);
    }

    public static void SubQue7() {
        // Declare a method-local variable strNumber of type String with some short value and convert it to the corresponding wrapper class using Short.valueOf(). (Hint: Use Short.valueOf(String)).
        String strNumber = "150";

        Short wrapperNumber = Short.valueOf(strNumber);

        System.out.println("Wrapper class value: " + wrapperNumber);
    }

    public static void SubQue8() {
        // Experiment with converting a short value into other primitive types or vice versa and observe the results.
        int intValue = 100;

        // Convert int to other primitive types
        byte byteValue = (byte) intValue;
        short shortValue = (short) intValue;
        long longValue = (long) intValue;
        float floatValue = (float) intValue;
        double doubleValue = (double) intValue;
        char charValue = (char) intValue;

        // Convert back to int from other types
        int byteToInt = byteValue;
        int shortToInt = shortValue;
        int longToInt = (int) longValue;
        int floatToInt = (int) floatValue;
        int doubleToInt = (int) doubleValue;
        int charToInt = (int) charValue;


        System.out.println("int to byte: " + byteValue);
        System.out.println("int to short: " + shortValue);
        System.out.println("int to long: " + longValue);
        System.out.println("int to float: " + floatValue);
        System.out.println("int to double: " + doubleValue);
        System.out.println("int to char: " + charValue + " (ASCII char: '" + (char) charValue + "')");


        System.out.println("byte to int: " + byteToInt);
        System.out.println("short to int: " + shortToInt);
        System.out.println("long to int: " + longToInt);
        System.out.println("float to int: " + floatToInt);
        System.out.println("double to int: " + doubleToInt);
        System.out.println("char to int: " + charToInt);
    }

    public static void main(String[] args) {

        SubQue1();
        SubQue2();
        SubQue3();
        SubQue4();
        SubQue5();
        SubQue6();
        SubQue7();

    }
}
