public class Que5 {

    public static void SubQue1() {
        // Write a program to test how many bytes are used to represent a long value using the BYTES field. (Hint: Use Long.BYTES).
        int longBytes = Long.BYTES;

        System.out.println("Number of bytes used by an int " + longBytes + " bytes.");

    }

    public static void SubQue2() {
        // Write a program to find the minimum and maximum values of long using the MIN_VALUE and MAX_VALUE fields. (Hint: Use Long.MIN_VALUE and Long.MAX_VALUE).
        long Min_value = Long.MIN_VALUE;
        long Max_value = Long.MAX_VALUE;

        System.out.println("Minimum long " + Min_value);
        System.out.println("Maximum long " + Max_value);

    }

    public static void SubQue3() {
        // . Declare a method-local variable number of type long with some value and convert it to a String using the toString method. (Hint: Use Long.toString(long)).
        long num = 12345678L;

        String numAsString = Long.toString(num);

        System.out.println("The Long number as a String is: " + numAsString);
    }

    public static void SubQue4() {
        // Declare a method-local variable strNumber of type String with some value and convert it to a long value using the parseLong method. (Hint: Use Long.parseLong(String)).
        String strNumber = "12345678";

        long num = Long.parseLong(strNumber);

        System.out.println("The string as an int is: " + num);
    }

    public static void SubQue5() {
        // Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to a long value. (Hint: parseLong method will throw a NumberFormatException).
        String strNumber = "Ab12Cd3";

        try {
            long num = Long.parseLong(strNumber);
            System.out.println("The string as an int is: " + num);
        } catch (NumberFormatException e) {
            System.out.println("Error: The string '" + strNumber + "' cannot be converted to an int.");
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public static void SubQue6() {
        // Declare a method-local variable number of type long with some value and convert it to the corresponding wrapper class using Long.valueOf(). (Hint: Use Long.valueOf(long)).
        long number = 12345678L;

        long wrapperNumber = Long.valueOf(number);

        System.out.println("The int as an Integer object is: " + wrapperNumber);
    }

    public static void SubQue7() {
        // Declare a method-local variable strNumber of type String with some long value and convert it to the corresponding wrapper class using Long.valueOf(). (Hint: Use Long.valueOf(String)).
        String strNumber = "12345678";

        long wrapperNumber = Long.valueOf(strNumber);

        System.out.println("The String as an Integer object is: " + wrapperNumber);
    }

    public static void SubQue8() {
        // Declare two long variables with values 1123 and 9845, and add them using a method from the Long class. (Hint: Use Long.sum(long, long)).
        long num1 = 1123 ;
        long num2 = 9845;

        long sum = Long.sum(num1, num2);

        System.out.println("Adding two integer value " + sum);
    }

    public static void SubQue9()  {
        // Declare two long variables with values 1122 and 5566, and find the minimum and maximum values using the Long class. (Hint: Use Long.min(long, long) and Long.max(long, long)).
        long num1 = 10;
        long num2 = 20;

        long Min_int = Long.min(num1, num2);
        long Max_int = Long.max(num1, num2);

        System.out.println("Maximum integer value " +Min_int);
        System.out.println("Maximum integer value " +Max_int);
    }

    public static void SubQue10() {
        // Declare a long variable with the value 7. Convert it to binary, octal, and hexadecimal strings using methods from the Long class. (Hint: Use Long.toBinaryString(long), Long.toOctalString(long), and Long.toHexString(long)).
        long num = 10;

        String binaryString = Long.toBinaryString(num);

        String octalString = Long.toOctalString(num);

        String hexString = Long.toHexString(num);

        System.out.println("The number" + num + "in binary is: " + binaryString);
        System.out.println("The number" + num + "in octal is: " + octalString);
        System.out.println("The number" + num + "in hexadecimal is: " + hexString);
    }

    public static void SubQue11() {
        // Experiment with converting a long value into other primitive types or vice versa and observe the results
        long longValue = 123456789L;

        // Convert int to other primitive types
        byte byteValue = (byte) longValue; // Narrowing conversion
        short shortValue = (short) longValue; // Narrowing conversion
        int intValue = (int) longValue; // Widening conversion
        float floatValue = (float) longValue; // Widening conversion
        double doubleValue = (double) longValue; // Widening conversion

        // Convert other primitive types to int
        byte byteToLong = 10;
        short shortToLong = 100;
        long longToLong = 123456789L; // Explicit casting needed
        float floatToLong = 45.67f; // Explicit casting needed
        double doubleToLong = 89.99; // Explicit casting needed

        long longFromByte = (long) byteToLong; // Widening conversion
        long longFromShort = (long) shortToLong; // Widening conversion
        long longFromLong = (long) longToLong; // Narrowing conversion
        long longFromFloat = (long) floatToLong; // Narrowing conversion
        long longFromDouble = (long) doubleToLong; // Narrowing conversion

        System.out.println("Original int value: " + intValue);
        System.out.println("int to byte: " + byteValue);
        System.out.println("int to short: " + shortValue);
        System.out.println("int to long: " + longValue);
        System.out.println("int to float: " + floatValue);
        System.out.println("int to double: " + doubleValue);

        System.out.println("byte to int: " + longFromByte);
        System.out.println("short to int: " + longFromShort);
        System.out.println("long to int: " + longFromLong);
        System.out.println("float to int: " + longFromFloat);
        System.out.println("double to int: " + longFromDouble);

    }


    public static void main(String[] args) {

        SubQue1();
        SubQue2();
        SubQue3();
        SubQue4();
        SubQue5();
        SubQue6();
        SubQue7();
        SubQue8();
        SubQue9();
        SubQue10();
        SubQue11();

    }

}
