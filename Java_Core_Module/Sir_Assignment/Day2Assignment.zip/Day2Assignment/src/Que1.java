import java.util.Scanner;
public class Que1 {

    public static void SubQue1() {
        Boolean bull = true;
        String status = Boolean.toString(bull);
        System.out.print("status: " + status);

        System.out.println();

    }

    public static void SubQue2() {
        String strStatus = "true";
        Boolean bullstatus = Boolean.parseBoolean(strStatus);
        System.out.print(bullstatus);

        System.out.println();
    }
    public static void SubQue3() {
        String strstatus1 = "1";
        Boolean bullstatus1 = strstatus1.equals("1");
        System.out.print(bullstatus1);

        System.out.println();

    }
    public static void SubQue4() {
        boolean Status = true;
        Boolean bullstatus = Boolean.valueOf(Status); // Autoboxing of primitive boolean
        System.out.print(bullstatus);

        System.out.println();
    }
    public static void SubQue5() {
        String strStatus  = "true";
        Boolean bullstatus = Boolean.valueOf(strStatus); // Autoboxing of primitive boolean
        System.out.print(bullstatus);

        System.out.println();
    }
    public static void SubQue6() {

//        Convert boolean to int

        boolean status = true;
        int int_value = status ? 1 : 0;
        System.out.print("Boolean to int: " + int_value);

        System.out.println();
    }

    public static void SubQue7() {

        boolean status = true;
        double doubleValue = status ? 1.0 : 0.0;
        System.out.println("Boolean to double: " + doubleValue);

        System.out.println();

    }

    public static void main(String[] args) {

        SubQue1();
        SubQue2();
        SubQue3();
        SubQue4();
        SubQue5();
        SubQue6();
        SubQue7();

    }
}
