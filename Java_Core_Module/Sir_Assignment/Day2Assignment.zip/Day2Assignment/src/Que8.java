public class Que8 {

    public static void main(String[] args) {
        // 8. Conversion between Primitive Types and Strings


        // Initialize variables of each primitive type with user-defined values
        int intValue = 42;
        long longValue = 123456789L;
        float floatValue = 3.14f;
        double doubleValue = 2.718;
        boolean booleanValue = true;
        char charValue = 'A';
        byte byteValue = 100;
        short shortValue = 32767;

        // Convert each primitive type to String using the toString method of the corresponding wrapper class
        String intToString = Integer.toString(intValue);
        String longToString = Long.toString(longValue);
        String floatToString = Float.toString(floatValue);
        String doubleToString = Double.toString(doubleValue);
        String booleanToString = Boolean.toString(booleanValue);
        String charToString = Character.toString(charValue);
        String byteToString = Byte.toString(byteValue);
        String shortToString = Short.toString(shortValue);

        // Convert each primitive type to String using the valueOf method of the String class
        String intValueOf = String.valueOf(intValue);
        String longValueOf = String.valueOf(longValue);
        String floatValueOf = String.valueOf(floatValue);
        String doubleValueOf = String.valueOf(doubleValue);
        String booleanValueOf = String.valueOf(booleanValue);
        String charValueOf = String.valueOf(charValue);
        String byteValueOf = String.valueOf(byteValue);
        String shortValueOf = String.valueOf(shortValue);


        System.out.println("int toString: " + intToString);
        System.out.println("long toString: " + longToString);
        System.out.println("float toString: " + floatToString);
        System.out.println("double toString: " + doubleToString);
        System.out.println("boolean toString: " + booleanToString);
        System.out.println("char toString: " + charToString);
        System.out.println("byte toString: " + byteToString);
        System.out.println("short toString: " + shortToString);

        System.out.println("int valueOf: " + intValueOf);
        System.out.println("long valueOf: " + longValueOf);
        System.out.println("float valueOf: " + floatValueOf);
        System.out.println("double valueOf: " + doubleValueOf);
        System.out.println("boolean valueOf: " + booleanValueOf);
        System.out.println("char valueOf: " + charValueOf);
        System.out.println("byte valueOf: " + byteValueOf);
        System.out.println("short valueOf: " + shortValueOf);

    }
}
