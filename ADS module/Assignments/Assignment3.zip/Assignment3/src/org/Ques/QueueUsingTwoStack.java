package org.Ques;

import java.util.Stack;

public class QueueUsingTwoStack {
    private Stack<Integer> stack1; 
    private Stack<Integer> stack2; 

    public QueueUsingTwoStack() {
        stack1 = new Stack<>();
        stack2 = new Stack<>();
    }

    public void enqueue(int value) {
        stack1.push(value); 
    }

    public int dequeue() {
        if (stack2.isEmpty()) { 
            while (!stack1.isEmpty()) {
                stack2.push(stack1.pop());
            }
        }
        
        if (stack2.isEmpty()) { 
            throw new IllegalStateException("Queue is empty");
        }
        
        return stack2.pop(); 
    }

    public void printQueue() {
        Stack<Integer> tempStack = new Stack<>();
        
        while (!stack2.isEmpty()) {
            tempStack.push(stack2.pop());
        }

        while (!tempStack.isEmpty()) {
            System.out.print(tempStack.peek() + " "); 
            stack2.push(tempStack.pop()); 
        }

        for (int i = stack1.size() - 1; i >= 0; i--) {
            System.out.print(stack1.get(i) + " ");
        }
        
        System.out.println(); 
    }

    public static void main(String[] args) {
    	QueueUsingTwoStack queue = new QueueUsingTwoStack();
        
        queue.enqueue(3);
        queue.enqueue(7);
        int dequeued1 = queue.dequeue();
        System.out.print("Queue = ");
        queue.printQueue(); 
        System.out.println("Dequeued element = " + dequeued1); 

        queue.enqueue(10);
        queue.enqueue(20);
        int dequeued2 = queue.dequeue();
        int dequeued3 = queue.dequeue();
        System.out.print("Queue = ");
        queue.printQueue(); 
        System.out.println("Dequeued elements = " + dequeued2 + ", " + dequeued3);  
    }
}

