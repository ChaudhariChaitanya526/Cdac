package org.Ques;

import java.util.Scanner;

/*6. Implement a Queue using an array.
•	Test Case 1:
Input: Enqueue 5, Enqueue 10, Dequeue
Output: Queue = [10], Dequeued element = 5
•	Test Case 2:
Input: Enqueue 1, 2, 3, Dequeue, Dequeue
Output: Queue = [3], Dequeued elements = 1, 2
*/


public class QueueUsingArray {
	
	private int[] queue;
	private int front;
	private int rear;
	private int size;
	private int n;
	
	public QueueUsingArray(int n) {
		this.n = n;
		queue = new int[n];
		front = 0;
		rear = -1;
		size = 0;
	}
	
	public void enqueue(int data) {
		if (size == n) {
			System.out.println("Queue is full");
			return;
		}
		rear = (rear + 1) % n;
		queue[rear] = data;
		size++;		
	}
	
	public int dequeue() {
		if (size == 0) {
			System.out.println("Queue is empty");
			return -1;
		}
		int item = queue[front];
		front = (front +1) % n;
		size--;
		return item;
	}
	
	public void displayQueue() {
		if (size == 0) {
			System.out.println("Queue is empty");
			return;
		}
		System.out.print("Queue: ");
		for (int i=0; i<size; i++) {
			System.out.print(queue[(front +i) % n] + " ");
		}
		System.out.println();
	}
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		QueueUsingArray queue = new QueueUsingArray(5);
		
		queue.enqueue(5);
		queue.enqueue(10);
		queue.displayQueue();
		
		System.out.println("Dequeued element = "+ queue.dequeue());
		queue.displayQueue();
		
		queue.enqueue(1);
		queue.enqueue(2);
		queue.enqueue(3);
		queue.displayQueue();
		
		System.out.println("Dequeued element = "+ queue.dequeue());
		queue.displayQueue();
		System.out.println("Dequeued element = " + queue.dequeue());
		queue.displayQueue();
		
	}
}
