package org.Ques;

/* 3. Reverse a string using a stack.

•	Test Case 1:
Input: "hello"
Output: "olleh"
•	Test Case 2:
Input: "world"
Output: "dlrow"
*/

import java.util.Scanner;

import java.util.Stack;

public class ReverseStringStack {
	
	public static String reverseString(String str) {
		
		Stack<Character> stack = new Stack<>();
		
		for (int i=0; i<str.length(); i++) {
			stack.push(str.charAt(i));
		}
		
		StringBuilder reverse = new StringBuilder();
		
		while(!stack.isEmpty()) {
			reverse.append(stack.pop());
		}
		
		return reverse.toString();
		
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a string");
		
		String str = sc.nextLine();
				
		System.out.println("Revesed string: "+ reverseString(str));
		
		sc.close();
		
	}

}
