package org.Ques;

/*  4. Evaluate a postfix expression using a stack.

•	Test Case 1:
Input: "5 3 + 2 *"
Output: 16
•	Test Case 2:
Input: "4 5 * 6 /"
Output: 3
 */

import java.util.Scanner;

public class postfixstack {

    public static int postfix(String str) {

        int[] stack = new int[str.length()];
        int top = -1;

        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);

            if (ch == ' ') {
                continue;
            }

            if (Character.isDigit(ch)) {
                stack[++top] = ch - '0';  
            } else {
                int val2 = stack[top--];  
                int val1 = stack[top--];

                switch (ch) {
                    case '+':
                        stack[++top] = val1 + val2;
                        break;
                    case '-':
                        stack[++top] = val1 - val2;
                        break;
                    case '*':
                        stack[++top] = val1 * val2;
                        break;
                    case '/':
                        stack[++top] = val1 / val2;
                        break;
                }
            }
        }
        return stack[top];
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter postfix expression:");
        String str = sc.nextLine();  
        
        System.out.println("Result: " + postfix(str));
        sc.close();
    }
}
