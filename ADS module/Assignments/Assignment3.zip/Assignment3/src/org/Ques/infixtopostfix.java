package org.Ques;

import java.util.Scanner;

/* . Convert an infix expression to postfix using a stack.
•	Test Case 1:
Input: "A + B * C"
Output: "A B C * +"
•	Test Case 2:
Input: "A * B + C / D"
Output: "A B * C D / +"
*/



public class infixtopostfix {
	
	
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String str = sc.nextLine();
		
		String [] arr = str.split(" ");
		
			
		
		
	}

}
