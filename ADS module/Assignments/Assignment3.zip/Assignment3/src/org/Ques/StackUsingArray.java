package org.Ques;


/* Queue using Array*/

import java.util.Scanner;

public class StackUsingArray {
	
	private int[] arr;
	private int top;
	private int nsize;	
	
	public StackUsingArray(int size) {
		arr = new int[size];
		nsize = size;
		top= -1;
	}
	
	public void push(int data) {
		if (top == nsize-1) {
			System.out.println("Stack Overflow");
		} else {
			arr[++top] = data;
		}
	}
	
	public int pop() {
		if (top == -1) {
			System.out.println("Stack Underflow");
			return -1;
		} else {
			return arr[top--];
		}
		
	}
	
	public void display() {
		if (top == -1) {
			System.out.println("Stack is empty");
		} else {
			System.out.print("Stack = [");
			for (int i=0; i<= top; i++) {
				if (i == top) {
					System.out.print(arr[i]);
				} else {
					System.out.print(arr[i]+ ", ");
				}
			}
			System.out.println("]");
		}
	}
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the size");
		
		int n = sc.nextInt();
		
		StackUsingArray stack = new StackUsingArray(n);
		
		stack.push(5);
		stack.push(6);
		stack.push(7);
		stack.display();
		
		int poppedEle = stack.pop();
		System.out.println("Popped element = " +poppedEle);
		
		stack.display();
		
		System.out.println();
		
		stack.push(8);
		stack.display();
		
		
	}
}
