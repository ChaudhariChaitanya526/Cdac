package org.Ques;

import java.util.Scanner;

/* 7. Implement a Circular Queue using an array.
•	Test Case 1:
Input: Enqueue 4, 5, 6, 7, Dequeue, Enqueue 8
Output: Queue = [8, 5, 6, 7]
•	Test Case 2:
Input: Enqueue 1, 2, 3, 4, Dequeue, Dequeue, Enqueue 5
Output: Queue = [5, 3, 4]
*/

public class CircularQueue {
	
	private int[] queue;
	private int front;
	private int rear;
	private int size;
	private int n;
	
	public CircularQueue(int n) {
		this.n = n;
		queue = new int[n];
		front = 0;
		rear = -1;
		size = 0;
	}
	
	public void enqueue(int data) {
		if (size == n) {
			System.out.println("Queue is full");
			return;
		}
		
		rear = (rear + 1) % n;
		queue[rear] = data;
		size++;
	}
	
	public int dequeue() {
		if (size == 0) {
			System.out.println("Queue is empty");
			return -1;
		}
		int item = queue[front];
		front = (front +1) % n;
		size--;
		return item;
	}
	
	public void diplayQueue() {
		if (size == 0) {
			System.out.println("Queue is empty");
			return;
		}
		for(int i=0; i<size; i++) {
			System.out.print(queue[(front + i) % n] + " ");
		}
		System.out.println();
		
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		CircularQueue queue = new CircularQueue(5);
		
		queue.enqueue(4);
		queue.enqueue(5);
		queue.enqueue(6);
		queue.enqueue(7);
		queue.diplayQueue();
		
		System.out.println("Dequeued element = " + queue.dequeue());
		queue.enqueue(8);
		queue.diplayQueue();
		
	}
	
}
